# Health_care_management_System
"We Care hospital" Management System is designed for manage details about hospital patient,employee and rooms(25). Designed by using HTML / CSS / JS / JQUERY/ PHP (procedural php) / MYSQL. 

Languages and Framworks HTML CSS JS PHP (procedural php) MYSQL JQUERY BOOTSTRAP

Import Database file from DATABASE and USERMANUAL folder.
User Manual Included
1)Create Account for System to create need to enter Top level Adminstration login details to system.

Top level Adminstration login  details.
Username = Admin
Password = Password

Example Super Admin Login
Username = superadmin
Password = 123

Example Basic Admin Login
Username = basic admin
Password = 1234
