
function display()
{
	if(document.getElementById('fieldsac').value=="ED")
	{
		document.getElementById('Button').disabled=false;
	}
	else
	{
		document.getElementById('Button').disabled = true;

	}

}
